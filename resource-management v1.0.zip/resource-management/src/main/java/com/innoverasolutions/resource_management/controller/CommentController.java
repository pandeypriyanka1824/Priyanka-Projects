package com.innoverasolutions.resource_management.controller;

import com.innoverasolutions.resource_management.model.Comment;
import com.innoverasolutions.resource_management.repository.CommentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/comments")
public class CommentController {

    private static final Logger logger = LoggerFactory.getLogger(CommentController.class);

    @Autowired
    private CommentRepository commentRepository;

    // Handle form submission and save comment
    @PostMapping("/send")
    public String sendComment(@RequestParam String message, @RequestParam String senderName) {
        // Log the incoming request details
        logger.info("Received POST request to /send with message: '{}' and sender: '{}'", message, senderName);

        // Create and save the comment
        Comment newComment = new Comment(message, senderName);
        commentRepository.save(newComment);

        // Log successful save operation
        logger.info("Comment saved successfully. Redirecting to view all comments.");

        return "redirect:/comments/view";  // Redirect to view comments
    }

    // View all comments
    @GetMapping("/view")
    public String viewComments(Model model) {
        logger.info("Received GET request to /view. Retrieving all comments.");

        model.addAttribute("comments", commentRepository.findAll());

        // Log the number of comments fetched
        logger.info("Found {} comments. Rendering comments-view page.", model.getAttribute("comments") != null ? ((Iterable) model.getAttribute("comments")).spliterator().getExactSizeIfKnown() : 0);

        return "comments-view";  // Render the comments-view.html page
    }
}
