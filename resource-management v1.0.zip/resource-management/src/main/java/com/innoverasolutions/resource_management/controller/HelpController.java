package com.innoverasolutions.resource_management.controller;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelpController {

    @GetMapping("ideator/help")
    public String helpPage() {
        // Add any dynamic model attributes if required
        return "Help"; // Maps to Help.html in the templates directory
    }
}